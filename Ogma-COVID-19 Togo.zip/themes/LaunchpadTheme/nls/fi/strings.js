define({
  "_themeLabel": "Launchpad-teema",
  "_layout_default": "Oletusasettelu",
  "_layout_right": "Oikea asettelu"
});