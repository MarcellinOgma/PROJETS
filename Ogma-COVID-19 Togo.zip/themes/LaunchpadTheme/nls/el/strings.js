define({
  "_themeLabel": "Θέμα Launchpad",
  "_layout_default": "Προεπιλεγμένη διάταξη",
  "_layout_right": "Δεξιά διάταξη"
});